from django.apps import AppConfig


class SilsonConfig(AppConfig):
    name = 'silson'
