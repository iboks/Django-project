JSONEditor.defaults.editors.object.options.collapsed = true;
JSONEditor.defaults.options.theme = 'bootstrap3';

